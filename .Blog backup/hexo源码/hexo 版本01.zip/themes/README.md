部署状态 | 集成结果 | 参考值
---|---|---
完成时间 | 2021-01-26 20:35:23 | yyyy-mm-dd hh:mm:ss
部署环境 |  +  | window \| linux + stable
部署类型 |  | push \| pull_request \| api \| cron
启用Sudo |  | false \| true
仓库地址 |  | owner_name/repo_name
提交分支 |  | hash 16位
提交信息 |  |
Job ID   |  |
Job NUM  |  |
