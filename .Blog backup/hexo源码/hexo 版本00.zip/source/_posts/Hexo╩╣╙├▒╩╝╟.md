---
title: Hexo使用笔记
categories:
  - 充电学习
tags:
  - 博客搭建
date: 2021-01-26 16:28:01
img: https://gitee.com/tigeedev/blog-image/raw/master/img/20210209124707.png
---

# 前言

这里只记录了自己在安装过程中所遇到的问题及解决方法。具体过程可参考以下两篇文章

# hexo搭建指南

具体教程：

[使用hexo+github搭建免费个人博客详细教程](http://blog.haoji.me/build-blog-website-by-hexo-github.html?from=xa)

[使用 Github Pages 和 Hexo 搭建自己的独立博客](https://www.itrhx.com/2018/08/15/A02-hexo-blog/)

两者可以搭配使用~

# 安装过程问题解决

## 本地安装hexo博客框架

需借助 npm 包管理器来安装。因为国内安装镜像源很慢，所以利用 npm 安装 cnpm。

用淘宝链接进行安装：

```git
$ npm install -g cnpm --registry=https://registry.npm.taobao.org
```

看下 cnpm 的版本：`cnpm -v`

<img src="https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150838.png" alt="image-20210126102457872"  />

然后用 cnpm 安装 Hexo 框架

```
$ cnpm install -g hexo-cli
```

用 hexo -v 验证，出现版本号说明安装成功

![image-20210126102938851](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150842.png)



## Hexo 初始化

本地新建名为 hexo 的文件夹（名字随便取），比如我的是：`D:\Workspace\hexo`，作为以后存放代码的地方

```
$ cd /D/Workspace/hexo/
$ hexo init
```

初始化执行 init 命令后一直在这个位置，这个地方折腾了好久才解决...

![image-20210126104206637](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150850.png)

不知过了多久，报了下面这个错误

一定要按自己的错误去找解决方法！！可参考官网解决：https://hexo.io/docs/troubleshooting.html

```
$ hexo init
INFO  Cloning hexo-starter https://github.com/hexojs/hexo-starter.git
fatal: unable to access 'https://github.com/hexojs/hexo-starter.git/': Failed to connect to localhost port 62603: Connection refused
WARN  git clone failed. Copying data instead
FATAL {
  err: [Error: ENOENT: no such file or directory, scandir 'C:\Users\Admin\AppData\Roaming\npm\node_modules\hexo-cli\assets'] {
    errno: -4058,
    code: 'ENOENT',
    syscall: 'scandir',
    path: 'C:\\Users\\Admin\\AppData\\Roaming\\npm\\node_modules\\hexo-cli\\assets'
  }
} 
```

其中有个错误如下，按路径查找发现没有 assets 文件夹，在对应位置手动创建一个即可

```
 err: [Error: ENOENT: no such file or directory, scandir 'C:\Users\Admin\AppData\Roaming\npm\node_modules\hexo-cli\assets']
```

再次初始化，这时发现还有一个错误，这个错误是因为我之前按照网上的方法，错误的给 git 设置了代理（代理端口为62603）

![image-20210126112410546](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150856.png)

取消 git 代理，然后再次重新初始化

如果提示 "  err: Error: target not empty"，把 hexo 文件夹里的文件全部删除，再次初始化即可。可以看到整个初始化的过程是非常快的

```
$ git config --global --unset http.proxy 
$ hexo init
```

![image-20210126113535838](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150900.png)

这时 hexo 会自动下载一些文件到这个目录，包括node_modules，目录结构如下图：

![初始化文件](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150907.png)

```
$ hexo g # 生成
$ hexo s # 启动服务
```

初始化完成，再次输入以上两个命令。hexo就会在public文件夹生成相关html文件，这些文件将来需要提交到github

![image-20210126114428337](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150915.png)

![image-20210126114634884](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150920.png)

`hexo s` 是开启本地预览服务，打开浏览器访问 http://localhost:4000 ，可以看到博客已经创建成功过啦！！！

首次初始化，会有一篇名为Hello World 的文章，默认界面就长这样：

![image-20210126114925030](https://gitee.com/tigeedev/blog-image/raw/master/img/20210208150924.png)
