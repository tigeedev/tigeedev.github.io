---
title: Hexo使用笔记
categories:
  - 充电学习
tags:
  - 博客搭建
date: 2021-01-26 16:28:01
img: https://gitee.com/tigeedev/blog-image/raw/master/img/20210209124707.png
---

## 【01】Hexo搭建指南

具体教程：

[使用hexo+github搭建免费个人博客详细教程](http://blog.haoji.me/build-blog-website-by-hexo-github.html?from=xa)

[使用 Github Pages 和 Hexo 搭建自己的独立博客](https://www.itrhx.com/2018/08/15/A02-hexo-blog/)

两者搭配使用，体验更佳~

------



## 【02】Markdown语法教程

教程：

[献给写作者的 Markdown 新手指南](https://www.jianshu.com/p/q81RER)

------



## 【03】Hexo博客优化

教程：

[Hexo 博客主题个性化](https://www.itrhx.com/2018/08/27/A04-Hexo-blog-topic-personalization/)

[Hexo 搭建个人博客系列：主题美化篇](http://yearito.cn/posts/hexo-theme-beautify.html)

[Hexo 博客提交百度、谷歌搜索引擎收录](https://www.itrhx.com/2019/09/17/A48-submit-search-engine-inclusion/)

------




