---
title: about
date: 2021-01-26 16:55:30
---

欢迎来到这里。

## 关于博客

&emsp;&emsp;本站采用 [Hexo](https://hexo.io/zh-cn/) 框架，使用 [Snippet](https://github.com/shenliyang/hexo-theme-snippet) 主题，托管于GitHub（已迁移到阿里云）。

&emsp;&emsp;搭建过程参考了不少大佬的文章，会同步更新于[Hexo使用笔记](https://www.tigeedev.com/2021/01/26/Hexo%E4%BD%BF%E7%94%A8%E7%AC%94%E8%AE%B0/) ，方便日后参考查看

