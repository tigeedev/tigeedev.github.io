hexo.on('ready', function() {
    hexo.log.info("=========================================");
    hexo.log.info("  Welcome to use Snippet theme for hexo  ");
    hexo.log.info("=========================================");
});